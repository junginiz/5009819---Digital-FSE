package com.example.bookstoreapi.repository;

public interface JpaRepository<Book, Long> {

}
