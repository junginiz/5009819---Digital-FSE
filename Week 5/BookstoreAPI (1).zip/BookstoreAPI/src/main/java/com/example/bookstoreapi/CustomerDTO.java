package com.example.bookstoreapi;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;
    private String address;

    // Getters and Setters
}
